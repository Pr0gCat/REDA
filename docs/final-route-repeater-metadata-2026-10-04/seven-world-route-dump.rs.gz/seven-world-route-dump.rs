use reda::frontend::{compile_systemverilog,CompileOptions,SourceInput};
use reda::compile::{compile,lowering::lower_optimised,planner::{plan_from_netlist,PortPlacements}};
fn main(){
 for top in ["feedback_counter","feedback_fsm","feedback_state_enable","reset_counter","hierarchy_reset_counter","reset_fsm","conditional_state_enable"] {
 let text=std::fs::read_to_string(format!("/home/seith/REDA/tests/fixtures/{top}.sv")).unwrap();
 let a=compile_systemverilog(&[SourceInput{name:top,text:&text}],&CompileOptions::new(top)).unwrap();
 let n=lower_optimised(&a.netlist).unwrap(); let physical=compile(&n).unwrap();
 let plan=plan_from_netlist(&n,&PortPlacements::default()).unwrap();
 let blocks:Vec<_>=physical.world.cells().iter().enumerate().filter_map(|(flat,&index)|{let b=physical.world.palette().get(index).unwrap();(b.kind!=reda::redstone::world::block::BlockKind::Air).then(||(physical.world.decode(flat),b))}).collect();
 let routes:Vec<_>=plan.routes().iter().enumerate().map(|(ordinal,r)|serde_json::json!({"ordinal":ordinal,"id":r.id(),"owner":r.owner(),"anchors":r.anchors(),"paths":r.branch_paths(),"terminals":r.terminals().iter().map(|t|serde_json::json!({"gate":t.sink.gate,"input_index":t.sink.input_index,"anchor":t.sink.anchor,"kind":format!("{:?}",t.kind),"repeaters":t.repeaters})).collect::<Vec<_>>() })).collect();
 println!("{}",serde_json::json!({"case":top,"lowered":n.gates.iter().map(|g|serde_json::json!({"output":g.output,"inputs":g.inputs,"kind":g.kind.wire_name()})).collect::<Vec<_>>(),"gates":physical.gate_output_positions,"inputs":physical.input_positions,"blocks":blocks,"routes":routes}));
}
}
