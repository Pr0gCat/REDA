use reda::compile::routing::*;
use reda::compile::fragment_synth::identity::{RouteId,PortId,PhysicalEndpointId,RoutedSinkId,ConnectionId,InstanceId};
use reda::compile::geometry::Anchor;
use reda::redstone::world::block::Facing;
fn at(x:i32,y:i32,z:i32)->Anchor { Anchor{x,y,z} }
fn main(){
 for (name,terminals,planned) in [
  ("forced_terminal",vec![at(12,1,4)],vec![]),
  ("already_planned_terminal",vec![at(18,1,4)],vec![]),
  ("body_plus_forced_terminal",vec![at(24,1,4)],vec![]),
  ("retained_prefix",vec![at(24,1,4),at(24,1,8)],vec![
   PlannedBranch{path:(4..=24).map(|x|at(x,1,4)).collect(),free_ends:false},
   PlannedBranch{path:(4..=20).map(|x|at(x,1,4)).chain((5..=8).map(|z|at(20,1,z))).chain((21..=24).map(|x|at(x,1,8))).collect(),free_ends:false},
  ]),
 ]{
  let id=RouteId(992);
  let source=RouteEndpoint{id:PhysicalEndpointId::PrimaryInput(PortId(992)),anchor:at(4,1,4),allowed_exit:Facing::East,terminal:TerminalContract::Source{signal_strength:15}};
  let sinks=NonEmptyRouteSinks::new(terminals.iter().enumerate().map(|(i,&anchor)|{let c=ConnectionId::External{instance:InstanceId(100+i as u32),input_index:i as u16};RouteSink{id:RoutedSinkId{route:id,ordinal:i as u16},endpoint:PhysicalEndpointId::Landing(c),anchor,allowed_entry:Facing::West,terminal:TerminalContract::Sink{target:RouteTarget::Connection(c),support:at(anchor.x+1,anchor.y,anchor.z),requirement:TerminalRequirement::Exact(RouteTerminalKind::BareMergeRepeater)}}}).collect()).unwrap();
  let reservations=PhysicalReservations::new();let request=RouteRequest{id,source,sinks:&sinks,reservations:&reservations,limits:RouterLimits{max_node_expansions:20000,max_queue_entries:80000}};
  let tree=DurablePhysicalRouter.route_planned(request,ForcedTerminalRunways::default(),&planned).unwrap();
  let actual:Vec<_>=tree.branches.iter().map(|branch|branch.path.iter().filter(|p|tree.cells.iter().any(|c|c.at==**p&&c.state.kind==reda::redstone::world::block::BlockKind::Repeater)).count()).collect();
  println!("{}",serde_json::json!({"case":name,"actual":actual,"tree":tree}));
 }
}
