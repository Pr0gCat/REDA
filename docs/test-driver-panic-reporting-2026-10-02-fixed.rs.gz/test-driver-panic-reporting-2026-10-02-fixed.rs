fn without_panic_output<T>(body: impl FnOnce()->T)->T {body()}

use std::sync::{Arc,atomic::{AtomicUsize,Ordering},mpsc};
fn main() {
 let reports=Arc::new(AtomicUsize::new(0));let counted=reports.clone();
 std::panic::set_hook(Box::new(move |_| {counted.fetch_add(1,Ordering::SeqCst);}));
 let (a_in_tx,a_in_rx)=mpsc::sync_channel(0);
 let (b_in_tx,b_in_rx)=mpsc::sync_channel(0);
 let (a_done_tx,a_done_rx)=mpsc::sync_channel(0);
 let a=std::thread::spawn(move || {
  without_panic_output(|| {a_in_tx.send(()).unwrap();b_in_rx.recv().unwrap();});
  a_done_tx.send(()).unwrap();
 });
 let b=std::thread::spawn(move || {
  a_in_rx.recv().unwrap();
  without_panic_output(|| {b_in_tx.send(()).unwrap();a_done_rx.recv().unwrap();});
 });
 a.join().unwrap();b.join().unwrap();
 let caught=std::panic::catch_unwind(||panic!("an unrelated failure must be reported"));
 assert!(caught.is_err());
 println!("reported_unrelated_panics={}",reports.load(Ordering::SeqCst));
}
